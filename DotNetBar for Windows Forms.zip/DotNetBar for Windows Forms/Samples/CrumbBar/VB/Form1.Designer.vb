<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits DevComponents.DotNetBar.Office2007Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.textBoxX1 = New DevComponents.DotNetBar.Controls.TextBoxX()
        Me.crumbBar2 = New DevComponents.DotNetBar.CrumbBar()
        Me.labelX2 = New DevComponents.DotNetBar.LabelX()
        Me.crumbBarItem3 = New DevComponents.DotNetBar.CrumbBarItem()
        Me.labelX1 = New DevComponents.DotNetBar.LabelX()
        Me.crumbBar1 = New DevComponents.DotNetBar.CrumbBar()
        Me.crumbBarItem1 = New DevComponents.DotNetBar.CrumbBarItem()
        Me.crumbBarItem2 = New DevComponents.DotNetBar.CrumbBarItem()
        Me.crumbBarItem4 = New DevComponents.DotNetBar.CrumbBarItem()
        Me.crumbBarItem5 = New DevComponents.DotNetBar.CrumbBarItem()
        Me.crumbBarItem6 = New DevComponents.DotNetBar.CrumbBarItem()
        Me.crumbBarItem7 = New DevComponents.DotNetBar.CrumbBarItem()
        Me.labelX3 = New DevComponents.DotNetBar.LabelX()
        Me.SuspendLayout
        '
        'textBoxX1
        '
        '
        '
        '
        Me.textBoxX1.Border.Class = "TextBoxBorder"
        Me.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.textBoxX1.Location = New System.Drawing.Point(9, 197)
        Me.textBoxX1.Multiline = true
        Me.textBoxX1.Name = "textBoxX1"
        Me.textBoxX1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.textBoxX1.Size = New System.Drawing.Size(327, 112)
        Me.textBoxX1.TabIndex = 10
        '
        'crumbBar2
        '
        Me.crumbBar2.AutoSize = true
        '
        '
        '
        Me.crumbBar2.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248,Byte),Integer), CType(CType(250,Byte),Integer), CType(CType(253,Byte),Integer))
        Me.crumbBar2.BackgroundStyle.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid
        Me.crumbBar2.BackgroundStyle.BorderBottomWidth = 1
        Me.crumbBar2.BackgroundStyle.BorderColor = System.Drawing.Color.FromArgb(CType(CType(83,Byte),Integer), CType(CType(89,Byte),Integer), CType(CType(94,Byte),Integer))
        Me.crumbBar2.BackgroundStyle.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(169,Byte),Integer), CType(CType(180,Byte),Integer), CType(CType(191,Byte),Integer))
        Me.crumbBar2.BackgroundStyle.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid
        Me.crumbBar2.BackgroundStyle.BorderLeftWidth = 1
        Me.crumbBar2.BackgroundStyle.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid
        Me.crumbBar2.BackgroundStyle.BorderRightWidth = 1
        Me.crumbBar2.BackgroundStyle.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid
        Me.crumbBar2.BackgroundStyle.BorderTopWidth = 1
        Me.crumbBar2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.crumbBar2.ContainerControlProcessDialogKey = true
        Me.crumbBar2.LicenseKey = "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F"
        Me.crumbBar2.Location = New System.Drawing.Point(7, 139)
        Me.crumbBar2.Name = "crumbBar2"
        Me.crumbBar2.PathSeparator = ";"
        Me.crumbBar2.Size = New System.Drawing.Size(329, 22)
        Me.crumbBar2.TabIndex = 9
        '
        'labelX2
        '
        '
        '
        '
        Me.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.labelX2.Location = New System.Drawing.Point(7, 83)
        Me.labelX2.Name = "labelX2"
        Me.labelX2.Size = New System.Drawing.Size(329, 50)
        Me.labelX2.TabIndex = 8
        Me.labelX2.Text = "Control with items created using code only. Use SelectedItemChanging and Selected"& _ 
    "ItemChanged events to be notified when selected item is changing."
        Me.labelX2.WordWrap = true
        '
        'crumbBarItem3
        '
        Me.crumbBarItem3.Image = Global.CrumbBar.My.Resources.Resources.dvdrom
        Me.crumbBarItem3.Name = "crumbBarItem3"
        Me.crumbBarItem3.Text = "DVD ROM"
        '
        'labelX1
        '
        '
        '
        '
        Me.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.labelX1.Location = New System.Drawing.Point(7, 2)
        Me.labelX1.Name = "labelX1"
        Me.labelX1.Size = New System.Drawing.Size(329, 43)
        Me.labelX1.TabIndex = 7
        Me.labelX1.Text = "Control with items added using VS.NET designer. Use Edit Items task in VS.NET to "& _ 
    "start items editor. Use SelectedItem property to select an item."
        Me.labelX1.WordWrap = true
        '
        'crumbBar1
        '
        Me.crumbBar1.AutoSize = true
        '
        '
        '
        Me.crumbBar1.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248,Byte),Integer), CType(CType(250,Byte),Integer), CType(CType(253,Byte),Integer))
        Me.crumbBar1.BackgroundStyle.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid
        Me.crumbBar1.BackgroundStyle.BorderBottomWidth = 1
        Me.crumbBar1.BackgroundStyle.BorderColor = System.Drawing.Color.FromArgb(CType(CType(83,Byte),Integer), CType(CType(89,Byte),Integer), CType(CType(94,Byte),Integer))
        Me.crumbBar1.BackgroundStyle.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(169,Byte),Integer), CType(CType(180,Byte),Integer), CType(CType(191,Byte),Integer))
        Me.crumbBar1.BackgroundStyle.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid
        Me.crumbBar1.BackgroundStyle.BorderLeftWidth = 1
        Me.crumbBar1.BackgroundStyle.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid
        Me.crumbBar1.BackgroundStyle.BorderRightWidth = 1
        Me.crumbBar1.BackgroundStyle.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid
        Me.crumbBar1.BackgroundStyle.BorderTopWidth = 1
        Me.crumbBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.crumbBar1.ContainerControlProcessDialogKey = true
        Me.crumbBar1.Items.Add(Me.crumbBarItem1)
        Me.crumbBar1.LicenseKey = "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F"
        Me.crumbBar1.Location = New System.Drawing.Point(7, 51)
        Me.crumbBar1.Name = "crumbBar1"
        Me.crumbBar1.PathSeparator = ";"
        Me.crumbBar1.SelectedItem = Me.crumbBarItem1
        Me.crumbBar1.Size = New System.Drawing.Size(329, 24)
        Me.crumbBar1.TabIndex = 6
        '
        'crumbBarItem1
        '
        Me.crumbBarItem1.Image = Global.CrumbBar.My.Resources.Resources.computer
        Me.crumbBarItem1.Name = "crumbBarItem1"
        Me.crumbBarItem1.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.crumbBarItem2, Me.crumbBarItem3})
        Me.crumbBarItem1.Text = "My Computer"
        '
        'crumbBarItem2
        '
        Me.crumbBarItem2.Image = Global.CrumbBar.My.Resources.Resources.hdd
        Me.crumbBarItem2.Name = "crumbBarItem2"
        Me.crumbBarItem2.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.crumbBarItem4, Me.crumbBarItem5, Me.crumbBarItem6, Me.crumbBarItem7})
        Me.crumbBarItem2.Text = "Drive C"
        '
        'crumbBarItem4
        '
        Me.crumbBarItem4.Image = Global.CrumbBar.My.Resources.Resources.folder
        Me.crumbBarItem4.Name = "crumbBarItem4"
        Me.crumbBarItem4.Text = "Drivers"
        '
        'crumbBarItem5
        '
        Me.crumbBarItem5.Image = Global.CrumbBar.My.Resources.Resources.folder
        Me.crumbBarItem5.Name = "crumbBarItem5"
        Me.crumbBarItem5.Text = "Program Files"
        '
        'crumbBarItem6
        '
        Me.crumbBarItem6.Image = Global.CrumbBar.My.Resources.Resources.folder
        Me.crumbBarItem6.Name = "crumbBarItem6"
        Me.crumbBarItem6.Text = "InetPub"
        '
        'crumbBarItem7
        '
        Me.crumbBarItem7.Image = Global.CrumbBar.My.Resources.Resources.folder
        Me.crumbBarItem7.Name = "crumbBarItem7"
        Me.crumbBarItem7.Text = "Windows"
        '
        'labelX3
        '
        '
        '
        '
        Me.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.labelX3.Location = New System.Drawing.Point(9, 176)
        Me.labelX3.Name = "labelX3"
        Me.labelX3.Size = New System.Drawing.Size(123, 15)
        Me.labelX3.TabIndex = 11
        Me.labelX3.Text = "Event log:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96!, 96!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(343, 311)
        Me.Controls.Add(Me.textBoxX1)
        Me.Controls.Add(Me.crumbBar2)
        Me.Controls.Add(Me.labelX2)
        Me.Controls.Add(Me.labelX1)
        Me.Controls.Add(Me.crumbBar1)
        Me.Controls.Add(Me.labelX3)
        Me.DoubleBuffered = true
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = false
        Me.MinimizeBox = false
        Me.Name = "Form1"
        Me.Text = "CrumbBar Control Sample Application"
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub
    Private WithEvents textBoxX1 As DevComponents.DotNetBar.Controls.TextBoxX
    Private WithEvents crumbBar2 As DevComponents.DotNetBar.CrumbBar
    Private WithEvents labelX2 As DevComponents.DotNetBar.LabelX
    Private WithEvents crumbBarItem3 As DevComponents.DotNetBar.CrumbBarItem
    Private WithEvents labelX1 As DevComponents.DotNetBar.LabelX
    Private WithEvents crumbBar1 As DevComponents.DotNetBar.CrumbBar
    Private WithEvents crumbBarItem1 As DevComponents.DotNetBar.CrumbBarItem
    Private WithEvents crumbBarItem2 As DevComponents.DotNetBar.CrumbBarItem
    Private WithEvents crumbBarItem4 As DevComponents.DotNetBar.CrumbBarItem
    Private WithEvents crumbBarItem5 As DevComponents.DotNetBar.CrumbBarItem
    Private WithEvents crumbBarItem6 As DevComponents.DotNetBar.CrumbBarItem
    Private WithEvents crumbBarItem7 As DevComponents.DotNetBar.CrumbBarItem
    Private WithEvents labelX3 As DevComponents.DotNetBar.LabelX

End Class
